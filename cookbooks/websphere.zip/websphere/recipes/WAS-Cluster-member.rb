=begin
websphere_cluster_member
  websphere_cluster_member 'automate29-member' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  bin_dir '/opt/IBM/WebSphere/AppServer/bin'
  cluster_name 'DEVMhix'
  server_node 'DEVWASHX02-Node29'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  server_name 'automate29'
  member_weight 99
  attributes ({
    'processDefinitions' => {
      'monitoringPolicy' => {
        'newvalue' => "[['maximumStartupAttempts', '2'], ['pingInterval', '222'], ['autoRestart', 'true'], ['nodeRestartState', 'PREVIOUS']]"
      },
      'jvmEntries' => {
        'newvalue' => "[['debugMode', 'true'], ['systemProperties',[[['name','my_custom_websphere_variable'],['value','testing2']]]]]"
      }
    }
  })
  action :create
  end
=end
  
 include_recipe "#{cookbook_name}::WAS-SAVE-CONFIG"
  
  websphere_cluster_member 'automate29-member' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  bin_dir '/opt/IBM/WebSphere/AppServer/bin'
  cluster_name 'DEVMhix'
  server_node 'DEVWASHX02-Node29'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  server_name 'automate29'
  member_weight 99
  attributes ({
    'processDefinitions' => {
      'monitoringPolicy' => {
        'newvalue' => "[['maximumStartupAttempts', '2'], ['pingInterval', '222'], ['autoRestart', 'true'], ['nodeRestartState', 'PREVIOUS']]"
      },
      'jvmEntries' => {
        'newvalue' => "[['debugMode', 'true'], ['systemProperties',[[['name','my_custom_websphere_variable'],['value','testing2']]]]]"
      }
    }
  })
  action :start
  end
