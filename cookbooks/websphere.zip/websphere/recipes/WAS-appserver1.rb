  websphere_profile 'DEVWWWhixmember01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  profile_name 'DEVWWWhixmember01'
  node_name 'DEVWASHX02-Node002'
  server_name 'DEVZZZhixmember01'
  profile_type 'appserver'
  action   [:create, :federate]
 end
 
=begin
 include_recipe "#{cookbook_name}::WAS-SAVE-CONFIG"
 
 websphere_profile 'DEVMhixmember01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  profile_name 'DEVMhixmember01'
  node_name 'DEVWASHX01-Node002'
  #server_name 'DEVMhixmember01'
  profile_type 'appserver'
  action :start
 end
 
 include_recipe "#{cookbook_name}::WAS-STARTSERVER"
 
 

 execute "start application " do
 cwd "/opt/IBM/WebSphere/AppServer/profiles/automate17/bin"
 command './startServer.sh automate17'
 end

execute "create application server" do
cwd "/opt/IBM/WebSphere/AppServer/bin"
command './manageprofiles.sh -create -profileName backup -profilePath /opt/IBM/WebSphere/AppServer/profiles/backup -templatePath /opt/IBM/WebSphere/AppServer/profileTemplates/default -hostName  mgr-Node -nodeName DEVWASHX0-NODE100 -serverName backup'
end

execute "federate application server" do
cwd "/opt/IBM/WebSphere/AppServer/profiles/backup/bin"
command './addNode.sh mgr-Node 8879 -profileName backup -username wasadmin -password wasadmin -includeapps -includebuses'
end

execute "start node" do
cwd "/opt/IBM/WebSphere/AppServer/profiles/backup/bin"
command './startNode.sh -profileName backup'
end
=end
