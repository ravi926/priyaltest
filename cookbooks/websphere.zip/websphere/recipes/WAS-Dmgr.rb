websphere_dmgr 'hixDmgr01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  cell_name 'DEVDMGRHX01-Cell01'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'dpmgr-Node'
  action  :start
end
websphere_dmgr 'iesDmgr01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  cell_name 'DEVDMGRHX01-Cell02'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'dpmgr-Node'
  action :start
end
websphere_dmgr 'porDmgr01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  cell_name 'DEVDMGRHX01-Cell03'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'dpmgr-Node'
  action :start
end

