websphere_app_server 'DEVMmember01' do
  node_name 'DEVWASHX01-NODE02'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  attributes ({
    'processDefinitions' => {
      'monitoringPolicy' => {
        'newvalue' => "[['maximumStartupAttempts', '2'], ['pingInterval', '222'], ['autoRestart', 'true'], ['nodeRestartState', 'PREVIOUS']]"
      },
      'jvmEntries' => {
        'newvalue' => "[['debugMode', 'true'], ['systemProperties',[[['name','my_custom_websphere_variable'],['value','testing2']]]]]"
      }
    }
  })
  action [:create, :start]
end
