websphere_cluster 'SITWThix' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  cluster_name 'SITWThix'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  action [:create, :start]
end
websphere_cluster 'DEVMhix' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  cluster_name 'DEVMhix'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  action [:create, :start]
end
