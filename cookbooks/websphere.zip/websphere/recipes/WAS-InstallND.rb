ibm_package 'WAS ND install' do
  package 'com.ibm.websphere.ND.v85'
  install_dir '/opt/IBM/WebSphere/AppServer'
  repositories ['/vagrant/WAS_ND85']
  imcl_dir '/opt/IBM/InstallationManager/eclipse/tools'
  action :install
end
