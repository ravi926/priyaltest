install_mgr 'ribapp install' do
 install_package "/vagrant/Install_Mgr_v1.6.2_Lnx_WASv8.5.5.zip"
 package_name 'com.ibm.cic.agent'
 ibm_root_dir '/opt/IBM'
 service_user 'ribapp'
 service_group 'ribapp'
  end
