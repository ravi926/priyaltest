
label = "test"
return_codes = "[0]"
bin_directory = "/opt/IBM/WebSphere/AppServer/profiles/DEVMhixmember01/bin"
        wsadmin_cmd_save = './wsadmin.sh -lang jython -conntype SOAP '
        wsadmin_cmd_save << " -host mgr-Node"
        wsadmin_cmd_save << " -port 8879"
        wsadmin_cmd_save << " -user wasadmin -password wasadmin " 
    #  wsadmin_cmd_save << " -c \"AdminServerManagement.startAllServers('DEVWASHX01-Node002')\""
		wsadmin_cmd_save << " -c \"AdminConfig.save()\""

puts wsadmin_cmd_save

        execute "wsadmin #{label}" do
          cwd bin_directory
          command wsadmin_cmd_save
#          returns return_codes
 #         sensitive sensitive_exec
          action :run
		  end
