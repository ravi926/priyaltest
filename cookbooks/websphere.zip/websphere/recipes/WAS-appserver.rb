websphere_profile 'automatemember01' do
  websphere_root '/opt/IBM/WebSphere/AppServer'
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  dmgr_host 'mgr-Node'
  dmgr_port '8879'
  profile_name 'automatemember01'
  node_name 'automatemember01-Node04'
  server_name 'automatemember01'
  profile_type 'appserver'
  action [:create, :federate, :start]
end
