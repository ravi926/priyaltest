
label = "test"
return_codes = "[0]"
bin_directory = "/opt/IBM/WebSphere/AppServer/profiles/DEVMhixmember01/bin"
        wsadmin_cmd_startserver = './wsadmin.sh -lang jython -conntype SOAP '
        wsadmin_cmd_startserver << " -host mgr-Node"
        wsadmin_cmd_startserver << " -port 8879"
        wsadmin_cmd_startserver << " -user wasadmin -password wasadmin " 
        wsadmin_cmd_startserver << " -c \"AdminServerManagement.startAllServers('DEVWASHX01-Node002')\""
	#	wsadmin_cmd_startserver << " -c \"AdminConfig.save()\""

puts wsadmin_cmd_startserver


        execute "wsadmin #{label}" do
          cwd bin_directory
          command wsadmin_cmd_startserver
#          returns return_codes
 #         sensitive sensitive_exec
          action :run
		  end
