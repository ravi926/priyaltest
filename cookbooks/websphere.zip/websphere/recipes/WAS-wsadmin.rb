=begin
websphere_wsadmin 'do some wsadmin' do
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  file "/vagrant/WAS-serverstart.py "
  dmgr_host 'mgr-Node'
  action [:run, :save]
end
=end
#=begin
websphere_wsadmin 'do some more wsadmin' do
  admin_user 'wasadmin'
  admin_password 'wasadmin'
  #script "\"AdminServerManagement.startAllServers('DEVWASHX02-NODE26')\""
  dmgr_port '8879'
  dmgr_host 'mgr-Node'
  action [:run, :save]
  end
#=end