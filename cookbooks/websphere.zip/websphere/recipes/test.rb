
label = "test"
return_codes = "[0]"
bin_directory = "/opt/IBM/WebSphere/AppServer/profiles/automate18/bin"
        wsadmin_cmd = './wsadmin.sh -lang jython -conntype SOAP '
        wsadmin_cmd << " -host mgr-Node"
        wsadmin_cmd << " -port 8879"
        wsadmin_cmd << " -user wasadmin -password wasadmin " 
        wsadmin_cmd << " -c \"AdminServerManagement.startAllServers('DEVWASHX02-Node27')\""
	#	wsadmin_cmd << " -c \"AdminConfig.save()\""

puts wsadmin_cmd


        execute "wsadmin #{label}" do
          cwd bin_directory
          command wsadmin_cmd
#          returns return_codes
 #         sensitive sensitive_exec
          action :run
		  end
