
label = "test"
return_codes = "[0]"
bin_directory = "/opt/IBM/WebSphere/AppServer/profiles/automate29/bin"
        wsadmin_cmd = './wsadmin.sh -lang jython -conntype SOAP '
        wsadmin_cmd << " -host mgr-Node"
        wsadmin_cmd << " -port 8879"
        wsadmin_cmd << " -user wasadmin -password wasadmin " 
		wsadmin_cmd << " -c \"AdminTask.createClusterMember(['-clusterName', 'DEVMhix', '-memberConfig', '[-memberNode   DEVWASHX02-Node29 "\
            "-memberName  automate29 -memberWeight  2 -genUniquePorts true -replicatorEntry  false]'])\""
       # wsadmin_cmd << " -c \"AdminServerManagement.startAllServers('DEVWASHX02-Node27')\""
	#	wsadmin_cmd << " -c \"AdminConfig.save()\""

puts wsadmin_cmd


        execute "wsadmin #{label}" do
          cwd bin_directory
          command wsadmin_cmd
#          returns return_codes
 #         sensitive sensitive_exec
          action :run
		  end

		  
		#   cmd = "AdminClusterManagement.createFirstClusterMemberWithTemplate('DEVMhix', 'DEVWASHX02-Node29', 'automate29', 'default')"
		
	#	  cmd = "AdminTask.createClusterMember(['-clusterName', 'DEVMhix', '-memberConfig', '[-memberNode   DEVWASHX02-Node29 "\
    #        "-memberName  automate29 -memberWeight  2 -genUniquePorts true -replicatorEntry  false]'])"
			
	#		  cmd = "AdminTask.createClusterMember(['-clusterName', '#{cluster_name}', '-memberConfig', '[-memberNode #{server_node} "\
        #    "-memberName #{server_name} -memberWeight #{member_weight} -genUniquePorts #{generate_unique_ports} -replicatorEntry #{session_replication}]'])"