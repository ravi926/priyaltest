default['im']['installation']['path'] 			     = "/opt/IBM/InstallationManager/eclipse/tools"
#default['im']['cache']['path']                   = "/DST/was_v85"
default['was85']['installation']['path']  		   = "/opt/IBM/WebSphere/AppServer/bin"
default['was85']['template']['path'] 	  		     = "/opt/IBM/WebSphere/AppServer/profileTemplates/default" 
# PROFILE
default['was85']['profile']['path']  	   		     = "/opt/IBM/WebSphere/AppServer/profiles"