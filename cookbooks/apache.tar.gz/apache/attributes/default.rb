default['chefserver']['ipaddress'] = '10.23.123.456'
default['chefserver']['hostname'] = 'chef-server.aws.com'
